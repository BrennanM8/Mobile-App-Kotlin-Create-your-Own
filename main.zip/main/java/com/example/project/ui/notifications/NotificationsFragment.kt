package com.example.project.ui.notifications

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import com.example.project.R
import com.example.project.databinding.ActivityMainBinding
import com.example.project.databinding.FragmentNotificationsBinding
import org.json.JSONException
import org.json.JSONObject
import java.nio.charset.Charset

class NotificationsFragment : Fragment() {

  private lateinit var notificationsViewModel: NotificationsViewModel
private var _binding: FragmentNotificationsBinding? = null
  // This property is only valid between onCreateView and
  // onDestroyView.
  private val binding get() = _binding!!

  override fun onCreateView(
    inflater: LayoutInflater,
    container: ViewGroup?,
    savedInstanceState: Bundle?
  ): View? {
    notificationsViewModel =
            ViewModelProvider(this).get(NotificationsViewModel::class.java)

    _binding = FragmentNotificationsBinding.inflate(inflater, container, false)
    val root: View = binding.root


    ///////////////////////////////////////////////

    val spMovies: Spinner = binding.spMovies
    val ivMovie: ImageView = binding.ivMovie
    val tvTitle: TextView = binding.tvTitle
    val tvYear: TextView = binding.tvYear
    val tvPlot: TextView = binding.tvPlot
    val btnTopMovies: Button = binding.btnTopMovies

    // read the file from raw resource
    val input_stream = resources.openRawResource(R.raw.movies)
    var movie_text = input_stream.readBytes().toString(Charset.defaultCharset())

    val myJSON_object = JSONObject(movie_text)
    var myJSON_array = myJSON_object.getJSONArray("movies")

    // horse names to be used in conjunction with spinner
    val movie_rank_and_name: MutableList<String> = ArrayList()

    // loop over array extract horse name and rank add to
    for(i in 0..(myJSON_array.length() - 1)) {
      //Toast.makeText(this,myJSON_array.getJSONObject(i).getString("horseName"),Toast.LENGTH_LONG).show()
      //get the individual properties of the JSON element
      val movie_title = myJSON_array.getJSONObject(i).getString("title")
      val movie_year = myJSON_array.getJSONObject(i).getString("year")
      //make the horse rank & name combo
     movie_rank_and_name.add("$movie_title. $movie_year")
    }

    val aa = ArrayAdapter(requireActivity(), R.layout.support_simple_spinner_dropdown_item, movie_rank_and_name)
    aa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item) // The drop down view
    spMovies.adapter = aa


    spMovies.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
      override fun onItemSelected(adapterView: AdapterView<*>, view: View, i: Int, l: Long) {
        val tvUserItem = view as TextView
        Toast.makeText(context, "You chose " + tvUserItem.text.toString(), Toast.LENGTH_SHORT).show()

        tvTitle.text = "  " + myJSON_array.getJSONObject(i).getString("title")
        tvYear.text = "  " + myJSON_array.getJSONObject(i).getString("year")
        tvPlot.text = "  " + myJSON_array.getJSONObject(i).getString("plot")
        Toast.makeText(context, " " + myJSON_array.getJSONObject(i).getString("pic"), Toast.LENGTH_SHORT).show()
        var iv_id = resources.getIdentifier(myJSON_array.getJSONObject(i).getString("pic"), "drawable", "com.example.project")
        ivMovie.setImageResource(iv_id)
      }
      override fun onNothingSelected(adapterView: AdapterView<*>) {}
    }



     //end onItemSelectedListener

    btnTopMovies.setOnClickListener {
      try {
        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/watch?v=cYROqsUAw0o")))
      } catch (e: JSONException) {
     }
    }//end setOnClickListener




    val textView: TextView = binding.tvNotifications
    notificationsViewModel.text.observe(viewLifecycleOwner, Observer {
      textView.text = textView.text.toString() + ""
    })
    return root
  }

override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}