package com.example.project.ui.dashboard

import android.content.Intent
import android.media.MediaPlayer
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import com.example.project.R
import com.example.project.databinding.FragmentDashboardBinding
import org.json.JSONException

class DashboardFragment : Fragment() {

  private lateinit var dashboardViewModel: DashboardViewModel
private var _binding: FragmentDashboardBinding? = null
  // This property is only valid between onCreateView and
  // onDestroyView.
  private val binding get() = _binding!!

  override fun onCreateView(
    inflater: LayoutInflater,
    container: ViewGroup?,
    savedInstanceState: Bundle?
  ): View? {
    dashboardViewModel =
            ViewModelProvider(this).get(DashboardViewModel::class.java)

    _binding = FragmentDashboardBinding.inflate(inflater, container, false)
    val root: View = binding.root

    val btnSound: Button = binding.btnSound
    val btnYTC: Button = binding.btnYTC
    val btnWIK: Button = binding.btnWIK

    // when button is clicked start "count down" timer
    btnSound.setOnClickListener {
      val mp = MediaPlayer.create(context, R.raw.clap)
      mp.start()
      //disable button so only one timer gets going at a time
      btnSound.isEnabled = false
    }

    btnYTC.setOnClickListener {
      try {
        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/watch?v=aWOFxyQI9D8")))
      } catch (e: JSONException) {
      }
    }//end setOnClickListener

    btnWIK.setOnClickListener {
      try {
        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://en.wikipedia.org/wiki/History_of_film")))
      } catch (e: JSONException) {
      }
    }//end setOnClickListener





    val textView: TextView = binding.tvOrigin
    dashboardViewModel.text.observe(viewLifecycleOwner, Observer {
      textView.text = textView.text.toString()+ ""
    })
    return root
  }

override fun onDestroyView() {
        super.onDestroyView()
        _binding = null


    }
}