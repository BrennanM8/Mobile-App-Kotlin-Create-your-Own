package com.example.project.ui.home

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import com.example.project.R
import com.example.project.databinding.FragmentHomeBinding
import android.content.SharedPreferences




class HomeFragment : Fragment() {

  private lateinit var homeViewModel: HomeViewModel
  private var _binding: FragmentHomeBinding? = null

  // This property is only valid between onCreateView and
  // onDestroyView.
  private val binding get() = _binding!!

  override fun onCreateView(
    inflater: LayoutInflater,
    container: ViewGroup?,
    savedInstanceState: Bundle?
  ): View? {
    homeViewModel =
      ViewModelProvider(this).get(HomeViewModel::class.java)

    _binding = FragmentHomeBinding.inflate(inflater, container, false)
    val root: View = binding.root

    val sbMovie: SeekBar = binding.sbMovie
    val tvNum: TextView = binding.tvNum
    val cbYes: CheckBox = binding.cbYes
    val cbNo: CheckBox = binding.cbNo
    val etFavorite: EditText = binding.etFavorite
    val btnDetermine: Button = binding.btnDetermine
    val tvResults: TextView = binding.tvResults

    // establish a shared preference and share preference editor
    // decalre shared preference and editor
    //val preferences = this.requireActivity().getSharedPreferences("pref", Context.MODE_PRIVATE)

    //var spp = preferences!!.getFloat("SPINNER",0f)
    //var etFav = preferences!!.getFloat("FAVORITE", 0f)


    //tvNum.setText("" + spp)
    //etFavorite.setText("" + etFav)            COMMENTED OUT THE PREFERENCES ... COULD NOT FIGURE IT OUT WITH THE FRAGMENTS



    btnDetermine.setOnClickListener {

      var results = etFavorite.text.toString()
      var number = tvNum.text.toString()

      if (cbYes.isChecked) {
        tvResults.text = "You would rather go to the theatres" +"-----"+ "Your favorite movie is" + " " + results +"-----"+ "You have seen" + " " +number + " " + "Amount of movies"

        if (cbNo.isChecked) {
          tvResults.text = "You would rather not go to the theatres"+"-----"+ "Your favorite movie is" + " " + results +"-----"+ "You have seen" + " " +number + " "+ "Amount of movies"

          //preferences.putFloat("SEEKBAR", spp)
          //preferences.putFloat("FAVORITE", etFavorite)


        }//end MainActivity
      }
    }

    // add seek bar event listener and handler -- requires three methods
    sbMovie.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
      //during the user's "sliding"
      override fun onProgressChanged(seekBar: SeekBar, i: Int, b: Boolean) {
        tvNum.text = "" + i
      }

      // in case you need to remember where you started
      override fun onStartTrackingTouch(seekBar: SeekBar) {}

      // in case you only want to act when the user is done "sliding"
      override fun onStopTrackingTouch(seekBar: SeekBar) {}
    }) //end setOnSeekBarChangeListener


    val textView: TextView = binding.tvHome
    homeViewModel.text.observe(viewLifecycleOwner, Observer {
      textView.text = textView.text.toString() + ""
    })
    return root
  }


  override fun onDestroyView() {
    super.onDestroyView()
    _binding = null
  }
}